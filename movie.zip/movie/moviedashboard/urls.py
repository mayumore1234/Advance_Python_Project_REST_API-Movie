from django.urls import path

from .api import MovieCreateApi,MovieApi, MovieDeleteApi,MovieUpdateApi

urlpatterns = [

    path('api/',MovieApi.as_view()),

    path('api/create',MovieCreateApi.as_view()),
    path('api/delete/<int:pk>',MovieDeleteApi.as_view()),
    path('api/update/<int:pk>',MovieUpdateApi.as_view()),

]