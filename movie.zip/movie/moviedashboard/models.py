from django.db import models

# Create your models here.
class Movie(models.Model):
    movie_name=models.CharField(max_length=100)
    type=models.CharField(max_length=100)
    actor_name=models.CharField(max_length=100)
    actress_name=models.CharField(max_length=100)
    release_date=models.CharField(max_length=150)
    description=models.TextField()
