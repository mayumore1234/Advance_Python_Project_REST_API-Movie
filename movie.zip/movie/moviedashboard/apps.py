from django.apps import AppConfig


class MoviedashboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'moviedashboard'
