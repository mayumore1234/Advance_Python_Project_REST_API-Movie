from rest_framework import generics
from rest_framework.response import Response
from .serializer import MovieSerializer
from .models import Movie

class MovieCreateApi(generics.CreateAPIView):

    queryset = Movie.objects.all()

    serializer_class = MovieSerializer

class MovieApi(generics.ListAPIView):
    queryset = Movie.objects.all()
    serializer_class = MovieSerializer

class MovieUpdateApi(generics.RetrieveUpdateAPIView):
    queryset = Movie.objects.all()
    serializer_class = MovieSerializer

class MovieDeleteApi(generics.DestroyAPIView):
    queryset=Movie.objects.all()
    serilizer_class=MovieSerializer